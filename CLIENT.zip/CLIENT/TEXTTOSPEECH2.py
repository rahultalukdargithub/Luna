import glob
import os
import signal
import sys
import time
import t2snew as t2sA
from playsound import playsound
import speech_recognition as sr

num = 1


def takecommand():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening.....")
        r.pause_threshold = 1.5
        audio = r.listen(source, timeout=10, phrase_time_limit=10)
    try:
        print("Recognizing....")
        query = r.recognize_google(audio, language='en-in')
        print("User said: \n", query)
    except Exception as e:
        print("Say that again please....")
        return "None"
    return query


def play_new_text_files(directory, played_files):
    files = sorted(glob.glob(os.path.join(directory, "*.txt")), key=lambda x: int(os.path.basename(x).split('.')[0]))
    for file_path in files:
        if file_path not in played_files:
            with open(file_path, 'r') as file:
                text = file.read()
                path = t2sA.te2sp(text)
                playsound(path)
                played_files.add(file_path)
                break  # Exit the loop to ensure one file is played at a time


def main():
    global num
    played_files = set()

    receive_directory = r"C:\\Users\\unrul\\OneDrive\\Desktop\\recieve"  # Change this to your directory

    def signal_handler(sig, frame):
        print("\nScript interrupted. Deleting contents of the directory.")
        delete_contents(receive_directory)
        sys.exit(0)

    def delete_contents(directory):
        for file in glob.glob(f"{directory}/*.txt"):
            os.remove(file)

    signal.signal(signal.SIGINT, signal_handler)

    while True:
        query = takecommand().lower()
        if query == "none":
            continue
        else:
            send_directory = f"C:\\Users\\unrul\\OneDrive\\Desktop\\send\\{num}.txt"
            num += 1
            with open(send_directory, 'w') as file:
                file.write(query)

            time.sleep(4)
            play_new_text_files(receive_directory, played_files)


if __name__ == "__main__":
    main()
