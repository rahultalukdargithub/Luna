#include <stdio.h>
#include <stdlib.h>

#define MAX 100

int stack[MAX];
int top = -1;
int stackSize;

void push() {
int value;
if (top == stackSize - 1) {
printf("Stack Overflow! Cannot push more elements.\n");
} else {
printf("Enter the value to be pushed: ");
scanf("%d", &value);
top++;
stack[top] = value;
printf("Pushed %d onto the stack.\n", value);
}
}
void pop() {
if (top == -1) {
printf("Stack Underflow! No elements to pop.\n");
} else {
printf("Popped %d from the stack.\n", stack[top]);
top--;
}
}
void peek() {
if (top == -1) {
printf("Stack is empty. No elements to peek.\n");
} else {
printf("Top element is %d.\n", stack[top]);
}
}

void display() {
if (top == -1) {
printf("Stack is empty.\n");
} else {
printf("Stack elements are:\n");
for (int i = top; i >= 0; i--) {
printf("%d\n", stack[i]);
}
}
}

int main() {
int choice;

// User input for stack size
printf("Enter the size of the stack (max %d): ", MAX);
scanf("%d", &stackSize);

if (stackSize > MAX) {
printf("Size exceeds the maximum allowed (%d). Setting to maximum size.\n", MAX);
stackSize = MAX;
}

while (1) {
printf("\nStack Operations Menu:\n");
printf("1. Push\n");
printf("2. Pop\n");
printf("3. Peek\n");
printf("4. Display\n");
printf("5. Exit\n");
printf("Enter your choice: ");
scanf("%d", &choice);

switch (choice) {
case 1:
push();
break;
case 2:
pop();
break;
case 3:
peek();
break;
case 4:
display();
break;
case 5:
printf("Exiting the program.\n");
exit(0);
default:
printf("Invalid choice! Please choose a valid option.\n");
}
}
return 0;
}
