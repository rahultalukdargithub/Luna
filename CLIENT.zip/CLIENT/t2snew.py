import requests
import uuid
# Define the API endpoint
url = "https://api.deepgram.com/v1/speak?model=aura-asteria-en"

# Set your Deepgram API key
api_key = "e336a20cb9ecceb0607297b8b4fb4cee48127156"


def te2sp(text:str)->str:
    # Define the headers
    headers = {
        "Authorization": f"Token {api_key}",
        "Content-Type": "application/json"
    }

    # Define the payload
    payload = {
        "text": text
    }

    # Make the POST request
    response = requests.post(url, headers=headers, json=payload)

    # Check if the request was successful
    save_file_path = f"{uuid.uuid4()}.mp3"
    t=""
    if response.status_code == 200:
        # Save the response content to a file
        with open(save_file_path, "wb") as f:
            f.write(response.content)
        print("File saved successfully.")
        t=save_file_path
    else:
        print(f"Error: {response.status_code} - {response.text}")
        t=f"Error: {response.status_code} - {response.text}"

    return t
